US Citizenship Test Practice — 500 Question Sets

Open index.html in Chrome, Edge, Firefox, or Safari.

Every refresh/new-set creates EXACTLY 500 randomized practice cards from the
2025 USCIS 128-question civics bank. Questions can repeat within a 500-card set;
this is intentional reinforcement rather than pretending there are 500 official USCIS questions.

The real 2025 test is separate: up to 20 questions from the 128-question bank,
with 12 correct required to pass.

Source: USCIS 2025 Civics Test, Form M-1778. Verify election/appointment and
state-specific answers before an interview.
